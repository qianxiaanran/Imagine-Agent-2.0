import React, { Suspense, useEffect, useState } from 'react';
import ThemeProvider from './context/ThemeContext';
import GlobalStyles from './components/GlobalStyles';
import LoadingScreen from './components/LoadingScreen';
import ErrorBoundary from './components/ErrorBoundary';
import {
  AUTH_REFRESH_TOKEN_KEY,
  AUTH_REMEMBER_UNTIL_KEY,
  AUTH_TOKEN_KEY,
} from './api/config';

const loadLandingPage = () => import('./pages/LandingPage');
const loadCapabilitiesPage = () => import('./pages/CapabilitiesPage');
const loadQuickStartPage = () => import('./pages/QuickStartPage');
const loadDashboardPage = () => import('./pages/Dashboard/DashboardPage');
const loadDecisionPage = () => import('./pages/DecisionCenterPage');
const loadSharedPage = () => import('./pages/Dashboard/SharedChatPage');
const loadAdminPage = () => import('./pages/Admin/AdminPage');
const loadLoginModal = () => import('./pages/Login/LoginModal');
const loadRegisterModal = () => import('./pages/Login/RegisterModal');

const LandingPage = React.lazy(loadLandingPage);
const CapabilitiesPage = React.lazy(loadCapabilitiesPage);
const QuickStartPage = React.lazy(loadQuickStartPage);
const DashboardPage = React.lazy(loadDashboardPage);
const DecisionCenterPage = React.lazy(loadDecisionPage);
const SharedChatPage = React.lazy(loadSharedPage);
const AdminPage = React.lazy(loadAdminPage);
const LoginModal = React.lazy(loadLoginModal);
const RegisterModal = React.lazy(loadRegisterModal);

let loginModalWarmPromise;
const warmLoginModal = () => {
  if (!loginModalWarmPromise) {
    loginModalWarmPromise = loadLoginModal();
  }
  return loginModalWarmPromise;
};

let supabaseClientPromise;
const getSupabaseClient = async () => {
  if (!supabaseClientPromise) {
    supabaseClientPromise = import('./api/supabaseClient').then((module) => module.supabase);
  }
  return supabaseClientPromise;
};

let userApiPromise;
const getUserApi = async () => {
  if (!userApiPromise) {
    userApiPromise = import('./api/user').then((module) => module.default);
  }
  return userApiPromise;
};

export default function App() {
  const [authModalView, setAuthModalView] = useState('closed');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentMode, setCurrentMode] = useState('general');
  const [isAuthReady, setIsAuthReady] = useState(false);

  const normalizedPath = (window.location.pathname || '/').replace(/\/+$/, '') || '/';
  const isShareRoute = normalizedPath.startsWith('/share/');
  const isAdminRoute = normalizedPath.startsWith('/admin');
  const isDecisionRoute = normalizedPath === '/decision';
  const isCapabilitiesRoute = normalizedPath === '/capabilities';
  const isQuickStartRoute = normalizedPath === '/quickstart';
  const shouldShowLoading = !isAuthReady;
  const rememberUntil = Number(localStorage.getItem(AUTH_REMEMBER_UNTIL_KEY) || 0);
  const hasStoredAuthHint = rememberUntil > 0 || !!localStorage.getItem(AUTH_TOKEN_KEY);
  const shouldInitializeAuthClient =
    !isShareRoute && (isAuthenticated || isAdminRoute || isDecisionRoute || hasStoredAuthHint);

  useEffect(() => {
    if (!shouldInitializeAuthClient) {
      return undefined;
    }

    let unsubscribe = null;
    let isDisposed = false;

    (async () => {
      const supabase = await getSupabaseClient();
      if (isDisposed) return;

      const { data } = supabase.auth.onAuthStateChange((event, session) => {
        const rememberUntil = Number(localStorage.getItem(AUTH_REMEMBER_UNTIL_KEY) || 0);
        if (!rememberUntil) return;
        const localToken = String(localStorage.getItem(AUTH_TOKEN_KEY) || '');
        const isSmsSessionToken = localToken.startsWith('sms-token-');

        if (rememberUntil <= Date.now()) {
          void supabase.auth.signOut();
          localStorage.removeItem(AUTH_REMEMBER_UNTIL_KEY);
          localStorage.removeItem(AUTH_TOKEN_KEY);
          localStorage.removeItem(AUTH_REFRESH_TOKEN_KEY);
          setIsAuthenticated(false);
          return;
        }

        // 验证码登录使用的是后端 sms-token，不应被 Supabase 事件覆盖或清空。
        if (isSmsSessionToken) {
          return;
        }

        if (session?.access_token) {
          localStorage.setItem(AUTH_TOKEN_KEY, session.access_token);
          if (session.refresh_token) {
            localStorage.setItem(AUTH_REFRESH_TOKEN_KEY, session.refresh_token);
          }
          return;
        }

        if (event === 'SIGNED_OUT') {
          localStorage.removeItem(AUTH_TOKEN_KEY);
          localStorage.removeItem(AUTH_REFRESH_TOKEN_KEY);
          localStorage.removeItem(AUTH_REMEMBER_UNTIL_KEY);
          setIsAuthenticated(false);
        }
      });

      unsubscribe = () => data?.subscription?.unsubscribe();
    })();

    return () => {
      isDisposed = true;
      unsubscribe?.();
    };
  }, [shouldInitializeAuthClient]);

  useEffect(() => {
    if (isShareRoute) {
      setIsAuthReady(true);
      loadSharedPage();
      return;
    }

    const preloadPublicPage = () => {
      if (isCapabilitiesRoute) {
        loadCapabilitiesPage();
        return;
      }
      if (isQuickStartRoute) {
        loadQuickStartPage();
        return;
      }
      loadLandingPage();
    };

    const checkAuth = async () => {
      let isValidSession = false;
      const settleAuth = () => setIsAuthReady(true);
      const applySessionToken = (session) => {
        if (session?.access_token) {
          localStorage.setItem(AUTH_TOKEN_KEY, session.access_token);
          if (session.refresh_token) {
            localStorage.setItem(AUTH_REFRESH_TOKEN_KEY, session.refresh_token);
          }
          return true;
        }
        return false;
      };

      try {
        const hasStoredToken = !!localStorage.getItem(AUTH_TOKEN_KEY);
        const hasAuthHint = rememberUntil > 0 || hasStoredToken;
        const localTokenHint = String(localStorage.getItem(AUTH_TOKEN_KEY) || '');
        const isSmsSessionToken = localTokenHint.startsWith('sms-token-');

        if (!hasAuthHint) {
          preloadPublicPage();
          settleAuth();
          return;
        }

        if (rememberUntil && !isSmsSessionToken) {
          const supabase = await getSupabaseClient();
          if (rememberUntil <= Date.now()) {
            await supabase.auth.signOut();
            localStorage.removeItem(AUTH_REMEMBER_UNTIL_KEY);
            localStorage.removeItem(AUTH_TOKEN_KEY);
            localStorage.removeItem(AUTH_REFRESH_TOKEN_KEY);
          } else {
            const { data } = await supabase.auth.getSession();
            const hasSessionToken = applySessionToken(data?.session);
            if (!hasSessionToken) {
              const { data: refreshed, error: refreshError } = await supabase.auth.refreshSession();
              if (!refreshError) {
                applySessionToken(refreshed?.session);
              }
            }
          }
        }

        const token = localStorage.getItem(AUTH_TOKEN_KEY);
        if (token) {
          try {
            const userApi = await getUserApi();
            const profile = await userApi.getProfile();
            if (profile && profile.id && profile.id !== 'anonymous') {
              isValidSession = true;
              setIsAuthenticated(true);
              if (isAdminRoute) {
                loadAdminPage();
              } else if (isDecisionRoute) {
                loadDecisionPage();
              } else {
                loadDashboardPage();
              }
            } else {
              localStorage.removeItem(AUTH_TOKEN_KEY);
              localStorage.removeItem(AUTH_REFRESH_TOKEN_KEY);
            }
          } catch (err) {
            console.warn('Token validation failed:', err);
            const message = String(err?.message || '');
            const isAuthError = /401|not logged in|invalid session|missing token|jwt/i.test(message);
            if (isAuthError) {
              localStorage.removeItem(AUTH_TOKEN_KEY);
              localStorage.removeItem(AUTH_REFRESH_TOKEN_KEY);
            }
          }
        }
      } catch (error) {
        console.error('Auth check logic error', error);
      } finally {
        if (!isValidSession) preloadPublicPage();
        settleAuth();
      }
    };

    void checkAuth();
  }, [isShareRoute, isAdminRoute, isDecisionRoute, isCapabilitiesRoute, isQuickStartRoute, rememberUntil]);

  useEffect(() => {
    if (shouldShowLoading) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = 'unset';
      };
    }

    const timer = setTimeout(() => {
      document.body.style.overflow = 'unset';
    }, 100);

    return () => clearTimeout(timer);
  }, [shouldShowLoading]);

  useEffect(() => {
    if (authModalView === 'closed') {
      return undefined;
    }

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.body.style.overflow = previousOverflow || 'unset';
    };
  }, [authModalView]);

  useEffect(() => {
    const updateAppHeight = () => {
      const height = window.innerHeight || document.documentElement.clientHeight;
      document.documentElement.style.setProperty('--app-height', `${height}px`);
    };

    updateAppHeight();
    window.addEventListener('resize', updateAppHeight);
    window.addEventListener('orientationchange', updateAppHeight);

    return () => {
      window.removeEventListener('resize', updateAppHeight);
      window.removeEventListener('orientationchange', updateAppHeight);
    };
  }, []);

  useEffect(() => {
    if (!isAuthReady || isAuthenticated || isShareRoute || isAdminRoute || isDecisionRoute) {
      return undefined;
    }

    let timeoutId = null;
    let idleId = null;
    let cancelled = false;

    const warm = () => {
      if (!cancelled) {
        void warmLoginModal();
      }
    };

    if (typeof window.requestIdleCallback === 'function') {
      idleId = window.requestIdleCallback(warm, { timeout: 1500 });
    } else {
      timeoutId = window.setTimeout(warm, 900);
    }

    return () => {
      cancelled = true;
      if (timeoutId) window.clearTimeout(timeoutId);
      if (idleId && typeof window.cancelIdleCallback === 'function') {
        window.cancelIdleCallback(idleId);
      }
    };
  }, [isAuthReady, isAuthenticated, isShareRoute, isAdminRoute, isDecisionRoute]);

  const openLoginModal = () => {
    void warmLoginModal();
    setAuthModalView('login');
  };

  const openRegisterModal = () => {
    loadRegisterModal();
    setAuthModalView('register');
  };

  const handleLoginSuccess = () => {
    setAuthModalView('closed');
    setIsAuthenticated(true);
    loadDashboardPage();
  };

  const handleRegisterSuccess = () => {
    setAuthModalView('closed');
    setIsAuthenticated(true);
    loadDashboardPage();
  };

  const handleLogout = () => {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_REFRESH_TOKEN_KEY);
    localStorage.removeItem(AUTH_REMEMBER_UNTIL_KEY);
    void getSupabaseClient().then((supabase) => supabase.auth.signOut());
    setIsAuthenticated(false);
    setCurrentMode('general');
    loadLandingPage();
  };

  return (
    <ErrorBoundary>
      <ThemeProvider>
        <GlobalStyles />

        <div className={`min-h-screen transition-opacity duration-700 ease-in-out ${shouldShowLoading ? 'opacity-0' : 'opacity-100'}`}>
          <Suspense
            fallback={
              shouldShowLoading ? (
                <div className="min-h-screen bg-white dark:bg-gray-950"></div>
              ) : (
                <LoadingScreen text="正在加载页面..." isVisible />
              )
            }
          >
            {isShareRoute ? (
              <SharedChatPage />
            ) : isAuthenticated ? (
              isAdminRoute ? (
                <AdminPage />
              ) : isDecisionRoute ? (
                <DecisionCenterPage />
              ) : (
                <DashboardPage onLogout={handleLogout} currentMode={currentMode} onModeChange={setCurrentMode} />
              )
            ) : isCapabilitiesRoute ? (
              <CapabilitiesPage onOpenLogin={openLoginModal} />
            ) : isQuickStartRoute ? (
              <QuickStartPage onOpenLogin={openLoginModal} />
            ) : (
              <LandingPage onOpenLogin={openLoginModal} />
            )}
          </Suspense>
        </div>

        <div className={`fixed inset-0 z-[9999] transition-opacity duration-500 ${shouldShowLoading ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <LoadingScreen
            text={
              isAuthenticated
                ? (isDecisionRoute ? '正在加载决策系统...' : '正在加载工作台...')
                : isShareRoute
                  ? '正在解析分享内容...'
                  : isDecisionRoute
                    ? '正在加载决策系统...'
                  : '正在启动智能引擎...'
            }
            isVisible={shouldShowLoading}
          />
        </div>

        <Suspense fallback={null}>
          {authModalView === 'login' && (
            <LoginModal
              isOpen
              onClose={() => setAuthModalView('closed')}
              onSwitchToRegister={openRegisterModal}
              onLoginSuccess={handleLoginSuccess}
            />
          )}

          {authModalView === 'register' && (
            <RegisterModal
              isOpen
              onClose={() => setAuthModalView('closed')}
              onSwitchToLogin={openLoginModal}
              onRegisterSuccess={handleRegisterSuccess}
            />
          )}
        </Suspense>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
